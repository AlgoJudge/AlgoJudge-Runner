// The model solution. Used to derive limits by calibration, never to judge.
#include <iostream>

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    long long a, b;
    std::cin >> a >> b;
    std::cout << a + b << "\n";
}
